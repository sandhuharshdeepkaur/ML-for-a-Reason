#%% Image Segmentation: Extract from the rest of the image
#We already did it as follwoing
#2.2 image_opencv_arithmetic.py
#2.3 image_opencv_contours.py
#2.4 image_opencv_filtering.py
#3. image_opencv_face_detection.py
#4. image_opencv_feature_detection.py
#6. image_tensorflow_object_detection.py
#7. image_digit_recognition.py
